import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, Lock, Unlock } from 'lucide-react';
import './Header.css'; 

export default function Header({ 
  isConnected, 
  account, 
  connectWallet, 
  disconnectWallet 
}) {
  return (
    <header className="header">
      <div className="header-container">
        <Link to="/" className="logo">
          <FileText className="logo-icon" />
          <h1 className="logo-text">DocuVerifyChain</h1>
        </Link>

        <nav className="nav-links">
          
          <Link to="/dashboard" className="nav-link">Dashboard</Link>
         
        </nav>

        <div className="header-actions">
          {isConnected ? (
            <div className="wallet-connected">
              <span className="wallet-address">
                {`${account.substring(0, 6)}...${account.substring(38)}`}
              </span>
              <button className="wallet-button" onClick={disconnectWallet}>
                <Unlock className="icon" />
                Disconnect
              </button>
            </div>
          ) : (
            <button className="wallet-button" onClick={connectWallet}>
              <Lock className="icon" />
              Connect Wallet
            </button>
          )}

          <div className="menu-dropdown">
            <button className="menu-button">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <line x1="4" x2="20" y1="12" y2="12" />
                <line x1="4" x2="20" y1="6" y2="6" />
                <line x1="4" x2="20" y1="18" y2="18" />
              </svg>
            </button>
            <div className="dropdown-content mobile">
              <Link to="/">Home</Link>
              <Link to="/dashboard">Dashboard</Link>
              <Link to="/verify">Verify</Link>
              {isConnected ? (
                <button onClick={disconnectWallet}>Disconnect Wallet</button>
              ) : (
                <button onClick={connectWallet}>Connect Wallet</button>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}