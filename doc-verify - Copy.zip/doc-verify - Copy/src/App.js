import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import DocVerifierJSON from './contracts/DocVerifier.json';
import './App.css';
import Header from './header';
import Footer from './Footer';

function App() {
  const [contract, setContract] = useState(null);
  const [status, setStatus] = useState('');
  const [selectedFile, setSelectedFile] = useState(null);
  const [account, setAccount] = useState('');
  const [isConnected, setIsConnected] = useState(false);

  // MetaMask connection
  const connectWallet = async () => {
    if (window.ethereum) {
      try {
        const provider = new ethers.BrowserProvider(window.ethereum);
        const accounts = await provider.send("eth_requestAccounts", []);
        setAccount(accounts[0]);
        setIsConnected(true);
        setStatus("✅ Wallet connected");
        initContract(provider);
      } catch (err) {
        setStatus(`❌ Error: ${err.message}`);
      }
    } else {
      setStatus("❌ MetaMask not detected");
    }
  };

  const disconnectWallet = () => {
    setAccount('');
    setIsConnected(false);
    setContract(null);
    setStatus("🦊 Wallet disconnected");
  };

  // Initialize contract with provider
  const initContract = async (provider) => {
    try {
      const signer = await provider.getSigner();
      const contract = new ethers.Contract(
        DocVerifierJSON.address,
        DocVerifierJSON.abi,
        signer
      );
      setContract(contract);
      setStatus("✅ Contract initialized");
    } catch (err) {
      setStatus(`❌ Contract initialization failed: ${err.message}`);
    }
  };

  // Check if wallet is already connected
  useEffect(() => {
    const checkConnection = async () => {
      if (window.ethereum?.isConnected()) {
        const provider = new ethers.BrowserProvider(window.ethereum);
        const accounts = await provider.listAccounts();
        if (accounts.length > 0) {
          setAccount(accounts[0].address);
          setIsConnected(true);
          initContract(provider);
        }
      }
    };
    checkConnection();
  }, []);

  // Enhanced file hashing function
  const hashFile = async (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const buffer = reader.result;
          const hash = ethers.keccak256(new Uint8Array(buffer));
          console.log(`Generated hash for ${file.name}:`, hash);
          resolve(hash);
        } catch (err) {
          console.error("Hashing failed:", err);
          reject(err);
        }
      };
      reader.onerror = (error) => {
        console.error("File reading error:", error);
        reject(error);
      };
      reader.readAsArrayBuffer(file);
    });
  };

  // Improved registration function
  const registerDocument = async () => {
    if (!selectedFile) {
      setStatus("❌ No file selected");
      return;
    }

    try {
      const hash = await hashFile(selectedFile);
      console.log("Registering hash:", hash);

      if (!contract) {
        setStatus("❌ Contract not loaded");
        return;
      }

      const alreadyExists = await contract.verifyDocumentHash(hash);
      if (alreadyExists) {
        setStatus(`ℹ️ Document already registered (Hash: ${hash.slice(0, 10)}...)`);
        return;
      }

      const tx = await contract.storeDocumentHash(hash);
      await tx.wait();
      setStatus(`✅ New document registered! (Hash: ${hash.slice(0, 10)}...)`);
      
    } catch (err) {
      console.error("Registration error:", err);
      setStatus(`❌ Registration failed: ${err.reason || err.message}`);
    }
  };

  // Enhanced verification function
  const verifyDocument = async () => {
    if (!selectedFile) {
      setStatus("❌ No file selected");
      return;
    }

    try {
      const hash = await hashFile(selectedFile);
      console.log("Verifying hash:", hash);

      if (!contract) {
        setStatus("❌ Contract not loaded");
        return;
      }

      const exists = await contract.verifyDocumentHash(hash);
      setStatus(exists 
        ? `✅ Document verified! (Hash: ${hash.slice(0, 10)}...)`
        : `❌ Document not found (New hash: ${hash.slice(0, 10)}...)`);
      
    } catch (err) {
      console.error("Verification error:", err);
      setStatus(`❌ Error: ${err.reason || err.message}`);
    }
  };

  const handleFileChange = (e) => {
    setSelectedFile(e.target.files[0]);
    setStatus('');
  };

  return (
    <div className="App">
      <Header
        isConnected={isConnected}
        account={account}
        connectWallet={connectWallet}
        disconnectWallet={disconnectWallet}
      />

      <main className={`main ${!isConnected ? 'disabled' : ''}`}>
        <div className="file-section">
          <input 
            type="file" 
            onChange={handleFileChange} 
            className="file-input"
            disabled={!isConnected}
          />
          <div className="actions">
            <button 
              onClick={registerDocument} 
              disabled={!selectedFile || !isConnected}
            >
              Register Document
            </button>
            <button 
              onClick={verifyDocument} 
              disabled={!selectedFile || !isConnected}
            >
              Verify Document
            </button>
          </div>
        </div>

        <div className={`status-box ${status.includes("✅") ? "success" : 
                        status.includes("❌") ? "error" : 
                        status.includes("ℹ️") ? "info" : ""}`}>
          {status}
        </div>
      </main>

      <Footer isConnected={isConnected} />
    </div>
  );
}

export default App;