import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css';

export default function Footer({ isConnected }) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-grid">
          <div className="footer-section">
            <h3 className="footer-title">DocuVerifyChain</h3>
            <p className="footer-text">
              A decentralized document verification platform powered by blockchain technology.
              Secure, transparent, and tamper-proof.
            </p>
            {isConnected && (
              <div className="wallet-status">
                <span className="status-indicator connected"></span>
                <span>Wallet Connected</span>
              </div>
            )}
          </div>

          <div className="footer-section">
            <h3 className="footer-title">Quick Links</h3>
            <ul className="footer-list">
              <li><Link to="/" className="footer-link">Home</Link></li>
              <li><Link to="/dashboard" className="footer-link">Dashboard</Link></li>
              <li><Link to="/verify" className="footer-link">Verify Documents</Link></li>
            </ul>
          </div>

          <div className="footer-section">
            <h3 className="footer-title">Resources</h3>
            <ul className="footer-list">
              <li><a href="https://ethereum.org" target="_blank" rel="noopener noreferrer" className="footer-link">Ethereum</a></li>
              <li><a href="https://metamask.io" target="_blank" rel="noopener noreferrer" className="footer-link">MetaMask</a></li>
              <li><a href="https://hardhat.org" target="_blank" rel="noopener noreferrer" className="footer-link">Hardhat</a></li>
            </ul>
          </div>
        </div>

        <div className="footer-bottom">
          <p>© {currentYear} DocuVerifyChain. All rights reserved.</p>
          {isConnected && (
            <div className="network-info">
              {/* You can add network information here if needed */}
            </div>
          )}
        </div>
      </div>
    </footer>
  );
}