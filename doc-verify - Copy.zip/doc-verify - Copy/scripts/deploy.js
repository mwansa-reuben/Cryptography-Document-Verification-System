const { ethers } = require("hardhat");

async function main() {
  const DocVerifier = await ethers.getContractFactory("DocVerifier");
  const docVerifier = await DocVerifier.deploy();

  console.log("Contract deployed to:", await docVerifier.getAddress());
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});