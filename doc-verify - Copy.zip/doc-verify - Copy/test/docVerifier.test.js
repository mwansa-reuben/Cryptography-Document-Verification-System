const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("DocVerifier", function () {
  let docVerifier;
  const testHash = ethers.keccak256(ethers.toUtf8Bytes("test"));

  before(async () => {
    const DocVerifier = await ethers.getContractFactory("DocVerifier");
    docVerifier = await DocVerifier.deploy();
  });

  it("Should register and verify a document", async function () {
    await docVerifier.storeDocumentHash(testHash);
    expect(await docVerifier.verifyDocumentHash(testHash)).to.equal(true);
  });

  it("Should reject duplicate documents", async function () {
    await expect(docVerifier.storeDocumentHash(testHash))
      .to.be.revertedWith("Document already registered");
  });
});